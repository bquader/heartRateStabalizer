//
//  HeartRate_equalizerApp.swift
//  HeartRate equalizer
//
//  Created by Barakah Quader on 11/23/23.
//

import SwiftUI

struct YourViewControllerWrapper: UIViewControllerRepresentable {
    let healthKitManager: HealthKitManager
    let yourViewController: YourViewController

    init(healthKitManager: HealthKitManager) {
        self.healthKitManager = healthKitManager
        self.yourViewController = YourViewController()
        self.yourViewController.healthKitManager = healthKitManager
    }

    func makeUIViewController(context: Context) -> YourViewController {
        return yourViewController
    }

    func updateUIViewController(_ uiViewController: YourViewController, context: Context) {
        // Update the view controller if needed
    }
}

@main
struct HeartRate_equalizerApp: App {
    let healthKitManager = HealthKitManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(healthKitManager)
                .overlay(YourViewControllerWrapper(healthKitManager: healthKitManager).frame(width: 0, height: 0))
        }
    }
}



