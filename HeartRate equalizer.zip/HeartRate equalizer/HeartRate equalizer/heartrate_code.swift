import Foundation
import UIKit
import HealthKit
import CoreBluetooth
import Combine


class HealthKitManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate, HKWorkoutSessionDelegate, ObservableObject {
    func workoutSession(_ workoutSession: HKWorkoutSession, didChangeTo toState: HKWorkoutSessionState, from fromState: HKWorkoutSessionState, date: Date) {
        // Handle workout session changes if needed
    }
    
    func workoutSession(_ workoutSession: HKWorkoutSession, didFailWithError error: Error) {
        // Handle workout session failure if needed
    }
    weak var delegate: CBCentralManagerDelegate?
    var centralManager: CBCentralManager!
    private var peripheral: CBPeripheral!
    private var characteristic: CBCharacteristic?
    private var timer: Timer?
    @Published var heartRate: Double = 0.0

    
    let serviceUUID = CBUUID(string: "BDDD2835-B629-CAC6-AF88-C2B416DF23D1")
    let characteristicUUID = CBUUID(string: "11111111-1111-1111-1111-111111111111")
    
    let healthStore = HKHealthStore()
    var heartRateCharacteristic: HKCharacteristicType?
    private let sendDataInterval: TimeInterval = 5.0
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
        startDataSendingTimer()
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            startBluetoothDiscovery()
            requestHealthKitAuthorization()
        } else {
            // HANDLE OTHER STATES
        }
    }
    
    private func startDataSendingTimer() {
        timer = Timer.scheduledTimer(timeInterval: sendDataInterval, target: self, selector: #selector(sendHeartRateData), userInfo: nil, repeats: true)
    }

    @objc private func sendHeartRateData() {
        // Modify this method to get the latest heart rate and send it to the Arduino
        readLatestHeartRate {
            // Handle completion if needed
        }
    }
    
    private func startBluetoothDiscovery() {
        centralManager.scanForPeripherals(withServices: [serviceUUID], options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi: NSNumber) {
        if peripheral.services?.contains(where: { $0.uuid == serviceUUID }) != nil {
            self.peripheral = peripheral
            self.peripheral.delegate = self
            centralManager.connect(peripheral, options: nil)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.discoverServices([serviceUUID])
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let service = peripheral.services?.first(where: { $0.uuid == serviceUUID }) {
            peripheral.discoverCharacteristics([characteristicUUID], for: service)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let characteristic = service.characteristics?.first(where: { $0.uuid == characteristicUUID }) {
            self.characteristic = characteristic
            peripheral.setNotifyValue(true, for: characteristic)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
            if let error = error {
                print("Error updating characteristic value: \(error.localizedDescription)")
                return
            }

            guard let data = characteristic.value else {
                print("No data received")
                return
            }

            if let heartRateDataString = String(data: data, encoding: .utf8) {
                if let heartRate = Double(heartRateDataString) {
                    print("Received Heart Rate: \(heartRate)")

                    // Update the @Published property to trigger the observation
                    self.heartRate = heartRate
                    sendToArduino(data: "Hello from iOS")
                } else {
                    print("Invalid Heart Rate Data Format")
                }
            } else {
                print("Unable to convert data to string")
            }
        }
    
    private func sendToArduino(data: String) {
        guard let characteristic = characteristic else { return }
        let dataToSend = data.data(using: .utf8)!
        peripheral.writeValue(dataToSend, for: characteristic, type: .withoutResponse)
    }
    
    private func requestHealthKitAuthorization() {
        let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate)!
        healthStore.requestAuthorization(toShare: nil, read: [heartRateType]) { success, error in
            if success {
                self.startHeartRateMonitoring()
            } else {
                // HANDLE AUTHORIZATION FAILURE
            }
        }
    }
    
    private func startHeartRateMonitoring() {
        guard let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate) else { return }
        
        let query = HKObserverQuery(sampleType: heartRateType, predicate: nil) { _, completionHandler, error in
            guard error == nil else {
                // HANDLE QUERY ERROR
                return
            }
            
            self.readLatestHeartRate(completionHandler: completionHandler)
        }
        
        healthStore.execute(query)
        healthStore.enableBackgroundDelivery(for: heartRateType, frequency: .immediate) { success, error in
            if success {
                // HANDLE BACKGROUND DELIVERY SUCCESS
            } else {
                // HANDLE BACKGROUND DELIVERY FAILURE
            }
        }
    }
    
    private func readLatestHeartRate(completionHandler: @escaping () -> Void) {
        guard let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate) else { return }

        let query = HKSampleQuery(sampleType: heartRateType, predicate: nil, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, results, error in
            guard error == nil else {
                // Handle the query error if needed
                print("Error in HKSampleQuery: \(error!.localizedDescription)")
                completionHandler()
                return
            }

            guard let result = results?.last as? HKQuantitySample else {
                // Handle the absence of results
                print("No results in HKSampleQuery")
                completionHandler()
                return
            }

            let heartRate = result.quantity.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
            print("Heart Rate: \(heartRate)")

            // SEND HEART RATE DATA TO BLUETOOTH HERE
            // SEND HEART RATE DATA TO BLUETOOTH HERE
            self.sendHeartRateToBluetooth(heartRate: heartRate)

            completionHandler()
        }

        healthStore.execute(query)
    }
    
    private func sendHeartRateToArduino(heartRate: Double) {
        // CONVERT AND SEND HEART RATE DATA TO BLUETOOTH MODULE
        let heartRateData = "\(heartRate)"
        sendToArduino(data: heartRateData)
    }

    private func sendHeartRateToBluetooth(heartRate: Double) {
        // Instantiate YourBluetoothManager and send heart rate data to Arduino
        let bluetoothManager = YourBluetoothManager()
        bluetoothManager.sendHeartRateData(heartRate)
    }

    func stopDataSendingTimer() {
        timer?.invalidate()
        timer = nil
    }
}


class YourBluetoothManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    var centralManager: CBCentralManager!
    var peripheral: CBPeripheral!
    var characteristics: [CBCharacteristic] = []

    // UUIDs for your Bluetooth service and characteristic
    let serviceUUID = CBUUID(string: "BDDD2835-B629-CAC6-AF88-C2B416DF23D1")
    let characteristicUUID = CBUUID(string: "11111111-1111-1111-1111-111111111111")

    // Replace with the actual heart rate data
    let heartRateData = "123"

    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
        centralManager.delegate = self
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            // Start scanning for peripherals
            centralManager.scanForPeripherals(withServices: [serviceUUID], options: nil)
        } else {
            // Handle other states
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi: NSNumber) {
        // Connect to the peripheral
        centralManager.connect(peripheral, options: nil)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        peripheral.discoverServices([serviceUUID])
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let service = peripheral.services?.first(where: { $0.uuid == serviceUUID }) {
            peripheral.discoverCharacteristics([characteristicUUID], for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
            if let serviceCharacteristics = service.characteristics {
                characteristics.append(contentsOf: serviceCharacteristics)
                
                // You may choose to send data immediately after discovering characteristics
                // sendHeartRateData(123) // Example with a heart rate value
            }
        }

        func sendHeartRateData(_ heartRate: Double) {
            // Convert and send heart rate data to Arduino
            let heartRateData = "\(heartRate)"
            
            // Safely unwrap the first characteristic before using it
            if let characteristic = characteristics.first {
                peripheral.writeValue(heartRateData.data(using: .utf8)!, for: characteristic, type: .withoutResponse)
            } else {
                print("Error: Characteristics not found")
            }
        }
    }
    
class YourViewController: UIViewController, CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
        } else {
        }
    }
    
    var healthKitManager: HealthKitManager!
    let bluetoothManager = YourBluetoothManager()

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set the delegate for the managers
        healthKitManager.delegate = self
                healthKitManager.centralManager.delegate = healthKitManager
                bluetoothManager.centralManager.delegate = bluetoothManager
        
        // Start Bluetooth and HealthKit operations
        startBluetoothAndHealthKit()
    }

    func startBluetoothAndHealthKit() {
        // Start Bluetooth operations
        if bluetoothManager.centralManager.state == .poweredOn {
            bluetoothManager.centralManagerDidUpdateState(bluetoothManager.centralManager)
        } else {
            // Handle Bluetooth not powered on
        }

        // Start HealthKit operations
        if healthKitManager.centralManager.state == .poweredOn {
            healthKitManager.centralManagerDidUpdateState(healthKitManager.centralManager)
        } else {
            // Handle HealthKit not powered on
        }
    }

    deinit {
        // Invalidate the timer to stop continuous data sending when the view controller is deallocated
        healthKitManager.stopDataSendingTimer()
    }
}

