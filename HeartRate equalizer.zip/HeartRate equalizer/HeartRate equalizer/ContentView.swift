//
//  ContentView.swift
//  HeartRate equalizer
//
//  Created by Barakah Quader on 11/23/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Listening to heartrate data")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
